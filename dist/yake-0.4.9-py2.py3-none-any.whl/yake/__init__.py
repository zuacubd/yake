# -*- coding: utf-8 -*-

"""Top-level package for yake."""

__author__ = """vitordouzi"""
__email__ = 'vitordouzi@gmail.com'
__version__ = '0.4.8'

from yake.yake import KeywordExtractor
